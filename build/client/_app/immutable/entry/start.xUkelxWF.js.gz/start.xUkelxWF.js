import{c as a}from"../chunks/entry.C0XtXUXW.js";export{a as start};
