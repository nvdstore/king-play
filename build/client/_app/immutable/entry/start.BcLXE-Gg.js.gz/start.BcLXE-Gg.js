import{c as a}from"../chunks/entry.D6cYmGy0.js";export{a as start};
