import{c as a}from"../chunks/entry.BDPKqPHQ.js";export{a as start};
