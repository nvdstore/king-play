import{c as a}from"../chunks/entry.eGK5Mmx5.js";export{a as start};
