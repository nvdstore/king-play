import{c as a}from"../chunks/entry.CvHxuCWh.js";export{a as start};
