import{c as a}from"../chunks/entry.Ck7nOtBn.js";export{a as start};
