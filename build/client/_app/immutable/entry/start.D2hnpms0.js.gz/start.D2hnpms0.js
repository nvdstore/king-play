import{c as a}from"../chunks/entry.CwivGntT.js";export{a as start};
