import{c as a}from"../chunks/entry.D_G1TyTl.js";export{a as start};
