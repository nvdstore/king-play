import{c as a}from"../chunks/entry.D67wGXNI.js";export{a as start};
