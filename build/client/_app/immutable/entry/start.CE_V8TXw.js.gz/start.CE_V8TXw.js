import{c as a}from"../chunks/entry.759eRd_i.js";export{a as start};
