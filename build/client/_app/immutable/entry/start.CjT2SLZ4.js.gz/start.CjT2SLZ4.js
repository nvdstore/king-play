import{c as a}from"../chunks/entry.BEL7CgLR.js";export{a as start};
