import{c as a}from"../chunks/entry.Dr0Jcpdl.js";export{a as start};
