import{c as a}from"../chunks/entry.DlJGxBc5.js";export{a as start};
