import{c as a}from"../chunks/entry.D57uCVz2.js";export{a as start};
