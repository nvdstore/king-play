import{c as a}from"../chunks/entry.Db1Qa4kA.js";export{a as start};
