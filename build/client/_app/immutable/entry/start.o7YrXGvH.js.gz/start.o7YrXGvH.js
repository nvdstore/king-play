import{c as a}from"../chunks/entry.S5W9R4Az.js";export{a as start};
