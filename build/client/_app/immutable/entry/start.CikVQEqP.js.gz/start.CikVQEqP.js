import{c as a}from"../chunks/entry.0SKrRbJw.js";export{a as start};
