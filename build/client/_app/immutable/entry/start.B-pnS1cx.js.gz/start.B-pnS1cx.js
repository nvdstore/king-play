import{c as a}from"../chunks/entry.MILWr-Un.js";export{a as start};
