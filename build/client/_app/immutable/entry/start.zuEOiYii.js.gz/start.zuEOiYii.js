import{c as a}from"../chunks/entry.dZgwb6_u.js";export{a as start};
