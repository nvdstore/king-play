import{c as a}from"../chunks/entry.CAuGH5yM.js";export{a as start};
