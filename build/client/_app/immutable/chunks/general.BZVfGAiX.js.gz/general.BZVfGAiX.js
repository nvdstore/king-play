import{w as e}from"./index.B4FbLfrC.js";let o=e(!1),s=e(!1);export{o,s};
