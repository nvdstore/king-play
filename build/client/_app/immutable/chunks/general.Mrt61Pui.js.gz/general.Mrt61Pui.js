import{w as e}from"./index.CKUPByak.js";let o=e(!1),s=e(!1);export{o,s};
