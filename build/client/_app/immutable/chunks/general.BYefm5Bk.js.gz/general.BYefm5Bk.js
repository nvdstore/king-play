import{w as e}from"./index.BQ1UVc3K.js";let o=e(!1),s=e(!1);export{o,s};
